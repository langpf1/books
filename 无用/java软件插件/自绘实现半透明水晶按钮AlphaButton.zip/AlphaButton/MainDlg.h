// MainDlg.h : ͷ�ļ�
//

#pragma once
#include "mybutton.h"
#include "afxwin.h"


// CMainDlg �Ի���
class CMainDlg : public CDialog
{
// ����
public:
	CMainDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_ALPHABUTTON_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��
public:
	CImage m_bkImage;

// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	CMyButton m_ButtonOk;
	CMyButton m_ButtonCancel;
	CMyButton m_Button1;
	CMyButton m_Button2;
	CMyButton m_Button3;
	CMyButton m_Button4;
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
};
